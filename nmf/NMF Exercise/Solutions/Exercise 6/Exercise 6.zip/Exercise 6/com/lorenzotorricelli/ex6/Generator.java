package com.lorenzotorricelli.ex6;

public enum Generator {
        AR, BM_AR, INV, BM; 
}
