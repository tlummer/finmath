package com.lorenzotorricelli.solex4;


public class BoxMuller {   //implements BivariateNormalRandomVariableGenerator: something for next Exercise Handout!
  private double mu;
private double sigma;
      public BoxMuller(double mu, double sigma) {
	this.mu = mu;
	this.sigma = sigma;
}
	public ReturnPair generate(){
    	  double u=Math.random();
    	  double v=Math.random();
    	  return new ReturnPair(sigma*Math.sqrt(-2.0*Math.log(u))*Math.cos(2*Math.PI*v)+mu ,
    			  sigma*Math.sqrt(-2.0*Math.log(u))*Math.sin(2*Math.PI*v)+mu);
      }
	
	
}
