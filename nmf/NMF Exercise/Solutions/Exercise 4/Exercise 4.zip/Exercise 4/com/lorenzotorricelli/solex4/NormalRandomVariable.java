package com.lorenzotorricelli.solex4;

import com.lorenzotorricelli.ex3sol.ExponentialRandomVariable;
import com.lorenzotorricelli.ex3sol.RandomVariable;

public class NormalRandomVariable implements RandomVariable{
	private double mu;
	private double sigma;
	private int orderOfErf=10;


	public NormalRandomVariable(double mu, double sigma){ //Constructor
		this.mu=mu;
		this.sigma=sigma;
	}
	
	public double getMu(){ //getter
			return mu;
		}

	public double getSigma(){ //getter
			return sigma;
		}

	
	
	@Override 
	 public double densityFunction(double x){
		return Math.exp(-x*x/2)/Math.sqrt(2*Math.PI);
}   //stdev and mu not involved (standard normal)

	

 public double cdfFunction(double x){
		return 0.5*(1+errorFunction((x-mu)/(Math.sqrt(2)*sigma)));
}   
	
	double errorFunction(double x){ //using taylor expansion; from Abramowitz and stegun
		double product=x;
		int factorial=1;
		double sum=x;
		for(int i=1;i<=orderOfErf; i++){
			factorial*=i;
			product*=x*x;
			sum+=parity(i)*product/(factorial*(2*i+1));
		}
		return sum*2/Math.sqrt(Math.PI);
	}
	
	double parity(int n){
		if(n%2==0) return 1;
		return -1;
	}
	
	
	@Override 
 public double quantileFunction(double x){
	if(x>0.5)
		return  sigma*complementaryQuantileFunction(1-x)+mu;
       return -sigma*complementaryQuantileFunction(x)+mu;
}   
	
public double complementaryQuantileFunction(double x){ //from Abramowitz and Stegun
		final double C0=2.515517;
	    final double C1=0.802853;
		final double C2=0.010328;
		final double D1=1.432788;
	    final double D2=0.189269;
		final double D3=0.001308;
	    double t=Math.sqrt(-2.0*Math.log(x));
           
		return t-(C0+C1*t+C2*t*t)/(1+D1*t+D2*t*t+D3*t*t*t); 
	}
	
	


	@Override
	public double generate(){  //generation
		return quantileFunction(Math.random());
	}	

	public double generateAR(){  //generation
		
		double u,y;
		
		ExponentialRandomVariable e=new ExponentialRandomVariable(1.0);
		do{
			
		u=Math.random();
		y=e.generate();
	

		} while(u> Math.exp(-(y-1)*(y-1)/2)) ; 
        if(Math.random()<0.5)
		return sigma*y+mu;
        else return -sigma*y+mu;
	}	
		
	
	

	@Override
	public double getStdError(){
		return getSigma();
	}
	
		public double getMean(){ //geeter
				return getMu();
			}
	


	@Override
	public double sampleMean(int n){
    	 double sm=0;
    	 for(int i=0; i<n; i++)
    		 sm+=generate();
    	 return sm/n;
     }
     
	


	


	}
	
	
	
