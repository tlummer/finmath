package com.lorenzotorricelli.solex5;

import com.lorenzotorricelli.solex4.NormalRandomVariable;

public class BiVariateNormalInversion implements BivariateNormalRandomVariableGenerator {
          
	NormalRandomVariable n1, n2;
	
	BiVariateNormalInversion(double mu, double sigma){
		n1=new NormalRandomVariable(mu, sigma);
        n2=new NormalRandomVariable(mu, sigma);
	}
	public ReturnPair generate(){
		return new ReturnPair(n1.generate(), n2.generate());
	}
}
