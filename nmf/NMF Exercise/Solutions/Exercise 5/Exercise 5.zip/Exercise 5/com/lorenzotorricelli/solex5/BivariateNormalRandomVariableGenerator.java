package com.lorenzotorricelli.solex5;


public interface BivariateNormalRandomVariableGenerator {
  ReturnPair generate();
}
