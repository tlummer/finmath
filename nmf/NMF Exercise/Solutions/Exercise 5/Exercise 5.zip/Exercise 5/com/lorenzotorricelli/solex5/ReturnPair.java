package com.lorenzotorricelli.solex5;

public class ReturnPair {
	private double firstPoint;   
	private  double secondPoint;
	public  ReturnPair(){ //default constructor
		firstPoint=0.0;
		secondPoint=0.0;
	}

	public  ReturnPair(double a, double b){ //Overloaded constructor
		firstPoint=a;
		secondPoint=b;
	}
	public void setFirstPoint(double a){
		firstPoint=a;}

	public void setSecondPoint(double a){
		secondPoint=a;
	}

	public void setPair(double a, double b){
		this.firstPoint=a;
		this.secondPoint=b;
	}

	public void setPair(ReturnPair i){
		this.firstPoint=i.firstPoint;   //OVERLOAD
		this.secondPoint=i.secondPoint;

	}


	public double getFirstPoint() {
		return firstPoint;
	}
	public double getSecondPoint() {
		return secondPoint;
	}
	public void printPair(){   //Todo: printFirstPoint, printSecond Point 
		System.out.println(" ( " + firstPoint + " , " +  secondPoint + " ) ");
	}
}


