package com.lorenzotorricelli.solex5;

public class BoxMullerAR implements BivariateNormalRandomVariableGenerator{
  private double mu;
private double sigma;
      public BoxMullerAR(double mu, double sigma) {
	this.mu = mu;
	this.sigma = sigma;
}
	public ReturnPair generate(){
    	  double u,v,r,s;
		  do{
		   u=2*Math.random()-1;
    	   v=2*Math.random()-1;
    	   r=u*u+v*v;
    	} while(r>1);
		   s=Math.sqrt(-2.0*Math.log(r)/r);
		  return new ReturnPair(sigma*u*s+mu , sigma*v*s+mu);
	
	}
	
	
	
	
}
