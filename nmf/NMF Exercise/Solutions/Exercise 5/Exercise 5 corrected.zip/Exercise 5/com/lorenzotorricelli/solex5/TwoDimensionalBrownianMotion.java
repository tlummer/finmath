package com.lorenzotorricelli.solex5;



public class TwoDimensionalBrownianMotion {
	private int numberOfSteps;
	private double stepsLength;      
	private ReturnPair initialValue;    //Uses arrays of Interval objects. an alternative is to define two separate arrays of double, one for each dimension
	private ReturnPair[] path;

	private ReturnPair[] increments;  //W_i+1-W_i



	public TwoDimensionalBrownianMotion(int numberOfSteps, double stepsLength, ReturnPair initialValue) {

		this.stepsLength = stepsLength; //UNIFORM SPACING
		this.initialValue=initialValue;
		this.numberOfSteps=numberOfSteps;
		path = new ReturnPair[this.numberOfSteps+1];
		increments = new ReturnPair[this.numberOfSteps];

	}

	ReturnPair getIncrement(int position){ return increments[position]; }    //get increment
	ReturnPair[] getPaths(){return path; }

	void generateBM(BivariateNormalRandomVariableGenerator generator){ //accepts interface type

		path[0]=initialValue; //new ReturnPair(initialValue.getFirstPoint(),initialValue.getSecondPoint());    //An array of objects only contains references. The objects, aren´t there yet, and must be created!


		double incrementSqrt=Math.sqrt(stepsLength);
		for(int i=0; i<numberOfSteps; i++){
			increments[i]=generator.generate();
			path[i+1]=new ReturnPair(path[i].getFirstPoint()+increments[i].getFirstPoint(), path[i].getSecondPoint()+increments[i].getSecondPoint());
		}
	}

	void printPath(){
		for(int i=0; i<path.length; i++)
			path[i].printPair();

	}

	void printIncrements(){
		for(int i=0; i<increments.length; i++)
			increments[i].printPair();

	}

	void printFirstBMPath(){
		for(int i=0; i<increments.length; i++)
			path[i].printFirstPoint();

	}

	
	void printSecondBMPath(){
		for(int i=0; i<increments.length; i++)
			path[i].printSecondPoint();

	}
}
