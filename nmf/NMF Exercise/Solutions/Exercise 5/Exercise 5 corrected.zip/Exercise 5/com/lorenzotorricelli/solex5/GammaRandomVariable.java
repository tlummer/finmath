package com.lorenzotorricelli.solex5;

import com.lorenzotorricelli.ex3sol.ExponentialRandomVariable;
import com.lorenzotorricelli.ex3sol.RandomVariable;


public class GammaRandomVariable implements RandomVariable{
	private double lambda;
	private double alpha;
	private double GammaBound=100;
	private int numberOfSimpsonIntervals=1000;
	

	GammaRandomVariable(double alpha, double lambda){ //Constructor
		this.alpha=alpha;
		this.lambda=lambda;
	}
	
	public double getLambda(){ //getter
			return lambda;
		}

	public double getAlpha(){ //getter
			return alpha;
		}
	
	
	@Override 
 public double quantileFunction(double x){
return x;
	}   
	


	@Override
	public double generate(){  //generation
		if(alpha<1.0){
			System.out.println("Cannot generate Gamma variables with this AR implemetation for such a value of alpha");
			return -1;
		}
		double u,y;
		
		double beta=lambda-alpha+1-0.001;
		ExponentialRandomVariable e=new ExponentialRandomVariable(beta);
		
		do{
			
		u=Math.random();
		y=e.generate();
		
//		System.out.println("y= " + y);
////		
//		System.out.println("g(y)= " + e.densityFunction(y));
//
//		System.out.println("f(y)= " + densityFunction(y));
//
//		System.out.println("u= " + u);
///
		} while(u>Math.exp((-lambda+beta)*y)*Math.pow(y, alpha-1)) ;
		return y;
	}	

	public double calculateEuler(double alpha){
		return Simpson.simpsonMethod(new GammaIntegrand(alpha), 0.0,GammaBound, numberOfSimpsonIntervals);
	}
	@Override
	public double densityFunction(double x){
		if(x<0) return 0;
		return  Math.pow(lambda, alpha)*Math.pow(x, alpha-1)*Math.exp(- lambda*x)/calculateEuler(alpha);
				
	}
 //Using abramowitz and stegun 	

	@Override
	public double getMean(){
		return alpha/lambda ;
	}
	
		public double getStdError(){ //getter
				return getMean()/lambda;
			}
	


	@Override
	public double sampleMean(int n){
    	 double sm=0;
    	 for(int i=0; i<n; i++)
    		 sm+=generate();
    	 return sm/n;
     }
     
	


	


	}
	
	
	
