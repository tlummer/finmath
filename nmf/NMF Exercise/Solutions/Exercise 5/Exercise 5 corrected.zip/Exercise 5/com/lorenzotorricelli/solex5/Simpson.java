package com.lorenzotorricelli.solex5;

public class Simpson {
	public static double simpsonMethod(Function<Double> f, double leftPoint, double rightPoint, int numberOfIntervals ){
		if(numberOfIntervals %2 == 1) numberOfIntervals+=1;
		double stepSize=(rightPoint-leftPoint)/(numberOfIntervals);
		double integral=stepSize/3.0*(f.evaluate(leftPoint)+f.evaluate(rightPoint));
		for(int i=1; i<=numberOfIntervals/2; i++){
			integral+=stepSize*4.0/3.0*(f.evaluate(leftPoint+(2*i-1)*stepSize)); 		  
		}
		for(int i=2; i<=numberOfIntervals/2-1; i++){
			integral+=stepSize*2.0/3.0*(f.evaluate(leftPoint+2*i*stepSize)); 		  
		}
		return integral;
	}
}
