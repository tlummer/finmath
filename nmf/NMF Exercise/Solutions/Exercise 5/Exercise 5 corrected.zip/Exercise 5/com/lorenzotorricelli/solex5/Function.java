package com.lorenzotorricelli.solex5;

public interface Function<T> {
	T evaluate(T x);
}
