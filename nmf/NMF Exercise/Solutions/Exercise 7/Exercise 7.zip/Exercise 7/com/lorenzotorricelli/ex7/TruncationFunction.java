package com.lorenzotorricelli.ex7;

import com.lorenzotorricelli.solex5.Function;


import net.finmath.stochastic.RandomVariableInterface;

public interface TruncationFunction extends Function<RandomVariableInterface>{

}
